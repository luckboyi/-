﻿


var domain = "http://7fvcp0.com2.z0.glb.qiniucdn.com/";

var list = ['./images/p1/mark.jpg',
            domain + 'p1_01.jpg',
            domain + 'p1_02.png',
            domain + 'p1_03.png',
            domain + 'p1_05.png',
            domain + 'p1_06.png',
            domain + 'p1_07.png',
            domain + 'p1_08.png',
            domain + 'p1_09.png',
            domain + 'dianwo.png',
            domain + 'p2_01.jpg',
            domain + 'p2_02.png',
            domain + 'p2_03.png',
            domain + 'p2_05.png',
            domain + 'p2_banner.png',
            domain + 'p2_people.png',
            domain + 'p2_phone.png',
            domain + 'p2_words.png',
            domain + 'p3_01.jpg',
            domain + 'p3_02.png',
            domain + 'p3_04.png',
            domain + 'p3_05.jpg',
            domain + 'p3_06.png',
            domain + 'p3_banner.png',
            domain + 'p3_people.png',
            domain + 'p3_words.png',
            domain + 'p4_banner.png',
            domain + 'p4_bg.jpg',
            domain + 'p4_boy.png',
            domain + 'p4_child.png',
            domain + 'p4_dog.png',
            domain + 'p4_jiege.png',
            domain + 'p4_mark.png',
            domain + 'p4_title.png',
            domain + 'p4_words.png',
            domain + 'p5_banner.png',
            domain + 'p5_bg.jpg',
            domain + 'p5_child.png',
            domain + 'p5_child2.png',
            domain + 'p5_fight.png',
            domain + 'p5_jiege.png',
            domain + 'p5_long.png',
            domain + 'p5_luopan.png',
            domain + 'p5_send.png',
            domain + 'p5_words.png',
            domain + 'p5_words2.png',
            domain + 'p5_xiaojiege.png',
            domain + 'p5_xiaolong.png',
            domain + 'sword.png',
            domain + 'p6_bg.jpg',
            domain + 'p6_luopan.png',
            domain + 'p6_subtitle.png',
            domain + 'p6_title.png',
            domain + 'p7_bg.jpg',
            domain + 'p7_btn.png',
            domain + 'p7_logo.png',
            domain + 'p7_words.png'
  ],    //此处省略一万个字符
    imgs = [];
function preloadImg(list, imgs) {
    var def = $.Deferred(),
        len = list.length;
    count = list.length;


    $(list).each(function (i, e) {
        var img = new Image();
        img.src = e;
        if (img.complete) {
            imgs[i] = img;
            len--;
            if (len == 0) {
                def.resolve();
            }
        }
        else {
            img.onload = (function (j) {
                return function () {
                    imgs[j] = img
                    len--;

                    var m = (imgs.length / count * 100).toFixed(0);


                    $(".load-status").text(m + "%");

                   // console.log(m);
                    if (len == 0) {
                        def.resolve();
                    }
                };
            })(i);
            img.onerror = function () {
                len--;
                //console.log('fail to load image');
            };
        }
    });
    return def.promise();
}






$.when(preloadImg(list, imgs)).done(
    function() {
        //预加载结束
        //do something here

        setTimeout(function() {
        $("#loadMark").remove();

        init();
        },1000);

    }
);

