function init(){
	alert(1)
}